using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using System.IdentityModel.Tokens.Jwt;
using Service;

namespace API {
    internal class AccessCodeAuthorizationHandler : AuthorizationHandler<AccessCodeRequirement> {
        private readonly ILogger<AccessCodeAuthorizationHandler> _logger;
        private readonly IJWTUtil jwtUtil;
        private string accessCodes;
        private readonly UserService _service;

        public AccessCodeAuthorizationHandler(ILogger<AccessCodeAuthorizationHandler> logger,
        IJWTUtil _jwtUtil, UserService service) {
            _logger = logger;
            jwtUtil = _jwtUtil;
            accessCodes = "";
            _service = service;
        }
        protected override Task HandleRequirementAsync(AuthorizationHandlerContext context,
            AccessCodeRequirement requirement) {
            string token;
            JwtSecurityToken jwtToken;
            List<Claim> effectiveClaims = new List<Claim>();
            HttpContext httpconcontext = (HttpContext)context.Resource;
            if (jwtUtil.ValidateToken(httpconcontext.Request, out jwtToken, out token)) {
                // Avoid hacker using other user's claims. Check the login user against the name in the JWT token
                if (context.User.Identity.Name ==
                    jwtToken.Claims.Where(c => c.Type == ClaimTypes.Name).Select(c => c.Value).SingleOrDefault()) {
                    Array.ForEach(jwtToken.Claims.Where(c => c.Type == ClaimTypes.Role)
                        .ToArray(), c => ((ClaimsIdentity)context.User.Identity).AddClaim(c));
                }
            }

            ClaimsPrincipal? userIdentity = context.User;
            if (userIdentity == null) return Task.CompletedTask; //Unauthorized anonymous user

            IEnumerable<Claim>? userClaims = userIdentity.Claims.Where(c => c.Type == ClaimTypes.Role);

            //if (userClaims.Count() == 0) {
            //    List<Claim>? claims = _service.GetUserClaims(context.User.Identity.Name);
            //    Array.ForEach(claims.Where(c => c.Type == ClaimTypes.Role).ToArray(),
            //        c => userClaims = userClaims.Append(c));
            //}

            foreach (Claim claim in userClaims) {
                accessCodes += claim.Value + "/";
            }

            if (accessCodes.Contains(requirement.Role)) {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
