using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using Autofac.Extensions.DependencyInjection;
using Autofac;
using API;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Data;
using Telerik.Reporting.Services;
using Telerik.Reporting.Cache.File;
using Microsoft.Identity.Web;

// Uncomment to enable NServiceBus
//using NServiceBus;
//using Messages;

const string CORS_ORIGINS = "CorsOrigins";

var builder = WebApplication.CreateBuilder(args);
// Windows Event logging
builder.Logging.ClearProviders();
builder.Logging.AddEventLog(eventLogSettings => {
    eventLogSettings.SourceName = ".NET Runtime";
});

// allow CORS
var hosts = builder.Configuration.GetSection(CORS_ORIGINS).Get<string[]>();
builder.Services.AddCors(option => {
    option.AddPolicy(name: "CORS_Policy",
        builder => {
            builder.WithOrigins(hosts)
                                .AllowAnyHeader()
                                .AllowAnyMethod()
                                .AllowCredentials();
        });
});
// Autofac
builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());
builder.Host.ConfigureContainer<ContainerBuilder>(cbuilder
    => cbuilder.RegisterModule(new API.RegisterModule(builder.Configuration.GetConnectionString("DDDConnectionString"))));

// Add AutoMapper
builder.Services.AddAutoMapper(typeof(Service.UserProfile).Assembly);
builder.Services.AddAutoMapper(typeof(Service.SystemParametersProfile).Assembly);


// Add other features
builder.Services.AddControllersWithViews(); // default PropertyNameCaseInsensitive false;PropertyNamingPolicy null; MaxDepth 64
builder.Services.AddHttpContextAccessor();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => {
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "DotNet6AAD_API", Version = "v1" });
    c.OperationFilter<CustomHeaderSwaggerAttribute>();
    c.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme {
        Name = "Authorization",
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.Http,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme."
    });
    c.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement {
        {
                new Microsoft.OpenApi.Models.OpenApiSecurityScheme {
                    Reference = new Microsoft.OpenApi.Models.OpenApiReference {
                        Type = Microsoft.OpenApi.Models.ReferenceType.SecurityScheme,
                        Id = "Bearer"
                    }
                },
                new string[] {}
        }
    });
    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
    c.IgnoreObsoleteActions();
    c.IgnoreObsoleteProperties();
    c.CustomSchemaIds(type => type.FullName);
});

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"));

builder.Services.AddMvc(options => {
    options.Filters.Add<ValidateAntiForgeryTokenAttribute>();
});

builder.Services.AddSingleton<IJWTUtil, JWTUtil>();
builder.Services.AddAntiforgery(options => {
    options.HeaderName = "X-CSRF-TOKEN-HEADER";
    options.Cookie.SameSite = SameSiteMode.None;
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
});

// for Blazor Telerik Report
builder.Services.AddRazorPages().AddNewtonsoftJson();
builder.Services.AddSingleton<IReportServiceConfiguration>(sp => new ReportServiceConfiguration
{
    Storage = new FileStorage(),
    ReportSourceResolver = new UriReportSourceResolver(
                        System.IO.Path.Combine(Directory.GetCurrentDirectory(), "Reports"))
});
// for IIS hosting
builder.WebHost.UseIIS();

// Uncomment to enable NService
//builder.Host.UseNServiceBus(context =>
//{
//    var endpointConfiguration = new EndpointConfiguration("API");
//    endpointConfiguration.UseTransport<LearningTransport>();

//    endpointConfiguration.SendFailedMessagesTo("error");
//    endpointConfiguration.AuditProcessedMessagesTo("audit");
//    endpointConfiguration.SendHeartbeatTo("Particular.ServiceControl");

//    var metrics = endpointConfiguration.EnableMetrics();
//    metrics.SendMetricDataToServiceControl("Particular.Monitoring", TimeSpan.FromMilliseconds(500));

//    return endpointConfiguration;

//});

var app = builder.Build();
app.UsePathBase("/");
/// <summary>
/// ///////////////////////////////////////////////////////////////////////////////////
/// </summary>
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment()) {
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("v1/swagger.json", "API v1"));
} else {
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
if (!builder.Environment.IsEnvironment("SpecFlow")) {
    using (var scope = app.Services.CreateScope()) {
        var dataContext = scope.ServiceProvider.GetRequiredService<EFContext>();
        dataContext.Database.Migrate();
    }
}
app.UseExceptionHandler("/Error");
app.UseMiddleware<ErrorHandler>();

app.UseHttpsRedirection();

app.UseRouting();
app.UseCors("CORS_Policy"); 
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();

// Define class name 'Program' for Specflow to work
public partial class Program { }