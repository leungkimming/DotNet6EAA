﻿
namespace Common {
    class Constants {
    }
}
