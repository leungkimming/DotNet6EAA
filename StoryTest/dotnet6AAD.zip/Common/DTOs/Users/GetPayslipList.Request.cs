﻿namespace Common {
    public class GetPayslipRequest : DTObaseRequest {
        public int userId { get; set; }
    }
}