﻿
namespace Common {
    public record Dep {
        public string DepartmentName { get; set; }
    }
}
