﻿namespace Common {
    public class DeleteUserRequest : DTObaseRequest {
        public int Id { get; set; }
    }
}