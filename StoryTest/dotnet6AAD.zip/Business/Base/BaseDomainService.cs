﻿
namespace Business {
    class BaseDomainService {
    }
}
