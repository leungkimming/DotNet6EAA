﻿namespace Business {
    public interface IAggregateRoot {
    }
}