﻿
namespace Business {
    class DomainException {
    }
}
