﻿using System;

namespace Platform
{
    class Program
    {
        #region PlatformMain

        static void Main()
        {
            Console.Title = "Particular Service Platform Launcher";
            Particular.PlatformLauncher.Launch();
        }

        #endregion
    }
}
