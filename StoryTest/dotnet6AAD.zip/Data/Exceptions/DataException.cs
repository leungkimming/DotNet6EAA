﻿
namespace Data {
    class DataException {
    }
}
