﻿using Business;

namespace Data {
    public interface IDepartmentRepository : IAsyncRepository<Department> {
    }
}