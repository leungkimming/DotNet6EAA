﻿
namespace Data {
    class DepartmentConfig {
    }
}
