﻿
namespace Data {
    class UserConfig {
    }
}
