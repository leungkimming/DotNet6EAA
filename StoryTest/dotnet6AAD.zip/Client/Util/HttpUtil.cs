﻿using Common;
using System.Net.Http.Json;
using Microsoft.JSInterop;
using Microsoft.AspNetCore.Components.WebAssembly.Authentication;
using System.Net;
using Microsoft.AspNetCore.Components;

namespace Client {
    public class HttpUtil {
        private readonly HttpClient _http;
        private readonly IJSRuntime _jSRuntime;
        private readonly NavigationManager _navigationManager;
        private readonly IAccessTokenProvider? _tokenProvider;
        public string BaseURL { get; set; }
        public HttpUtil(HttpClient http, IJSRuntime jsRuntime, 
            IServiceProvider serviceProvider, NavigationManager navigationManager,
            IConfiguration config) {
            _http = http;
            _jSRuntime = jsRuntime;
            _navigationManager = navigationManager;
            _tokenProvider = serviceProvider.GetService<IAccessTokenProvider>();
            BaseURL = config.GetSection("APIBaseAddress").GetValue(typeof(string), "URL").ToString();
        }
        public async Task<HttpResponseMessage> PostAsync(string? requestUri, HttpContent? content) {
            await RefreshToken();
            var response=await _http.PostAsync($"{requestUri}", content);
            ErrorHandler(response.StatusCode);
            return response;
        }
        public async Task<HttpResponseMessage> GetAsync(string? requestUri) {
            await RefreshToken();
            var response=await _http.GetAsync($"{requestUri}");
            ErrorHandler(response.StatusCode);
            return response;
        }

        private void ErrorHandler(HttpStatusCode? httpStatusCode) {
            if (httpStatusCode == HttpStatusCode.Forbidden) {
                _navigationManager.NavigateTo($"Error/{ErrorConstant.AuthorizationError.Code}");
                throw new OperationCanceledException($"{HttpStatusCode.Forbidden}:you don't has permission.");
            }
        }

        public async Task<HttpResponseMessage> PostAsJsonAsync(string? requestUri, object? content) {
            await RefreshToken();
            var response=await _http.PostAsJsonAsync($"{requestUri}", content);
            ErrorHandler(response.StatusCode);
            return response;
        }
        public async Task<T> GetFromJsonAsync<T>(string? requestUri) {
            await RefreshToken();
            try {
                var response=await _http.GetFromJsonAsync<T>($"{requestUri}");
                return response;
            } catch (HttpRequestException httpEx){
                ErrorHandler(httpEx.StatusCode);
            }
            return default(T);
        }
        public async Task<(string accessToken, RefreshTokenResponse refreshToken)> RefreshToken() {
            string accessToken = await GetAccessToken();
            if (!string.IsNullOrWhiteSpace(accessToken)) {
                _http.DefaultRequestHeaders.Remove("authorization");
                _http.DefaultRequestHeaders.Add("authorization", $"Bearer {accessToken}");
            }

            var refreshToken = await _http.GetFromJsonAsync<RefreshTokenResponse>("Login?force=false");
            _http.DefaultRequestHeaders.Remove("X-CSRF-TOKEN-HEADER");
            _http.DefaultRequestHeaders.Add("X-CSRF-TOKEN-HEADER", refreshToken!.CSRF_TOKEN);

            return (accessToken, refreshToken);
        }
        public async Task RefreshToken(Dictionary<string, object> requestHeaders) {
            var tokens = await RefreshToken();
            requestHeaders.Add("X-CSRF-TOKEN-HEADER", tokens.refreshToken.CSRF_TOKEN);
            if (!string.IsNullOrWhiteSpace(tokens.accessToken)){
                requestHeaders.Add("authorization", $"Bearer {tokens.accessToken}");
            }
        }
        public async Task<string> GetAccessToken(){
            if (_tokenProvider != null){
                var accessTokenResult = await _tokenProvider.RequestAccessToken();
                if (accessTokenResult.TryGetToken(out var token)){
                    return token.Value;
                }
            }
            return "";
        }
    }
}
